#include "rclcpp/rclcpp.hpp"
#include "training_interfaces/srv/value.hpp"
#include <chrono>
#include <cstdlib>
#include <memory>

using namespace std::chrono_literals;

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);

  if (argc != 3) {
    RCLCPP_ERROR(rclcpp::get_logger("rclcpp"), "Usage: service_client a b");
    return 1;
  }

  auto node = rclcpp::Node::make_shared("service_client");
  auto client = node->create_client<training_interfaces::srv::Value>("add_values");

  auto request = std::make_shared<training_interfaces::srv::Value::Request>();
  request->a = std::stoi(argv[1]);
  request->b = std::stoi(argv[2]);

  while (!client->wait_for_service(1s)) {
    if (!rclcpp::ok()) {
      RCLCPP_ERROR(rclcpp::get_logger("rclcpp"), "Interrupted while waiting for the service.");
      return 0;
    }
    RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Waiting for service to become available...");
  }

  auto result = client->async_send_request(request);

  if (rclcpp::spin_until_future_complete(node, result) == rclcpp::FutureReturnCode::SUCCESS) {
    RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Result: %d", result.get()->val);
  } else {
    RCLCPP_ERROR(rclcpp::get_logger("rclcpp"), "Failed to call service.");
  }

  rclcpp::shutdown();
  return 0;
}
