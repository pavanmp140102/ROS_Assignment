#include <functional>
#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "training_interfaces/msg/person.hpp"

using std::placeholders::_1;

class SubscriberNode : public rclcpp::Node
{
public:
  SubscriberNode() : Node("subscriber_node")
  {
    subscription_ = this->create_subscription<training_interfaces::msg::Person>(
      "person_topic", 10, std::bind(&SubscriberNode::topic_callback, this, _1));
  }

private:
  void topic_callback(const training_interfaces::msg::Person &msg) const
  {
    RCLCPP_INFO(this->get_logger(), "Received: Name: '%s', Age: '%d'", msg.name.c_str(), msg.age);
  }

  rclcpp::Subscription<training_interfaces::msg::Person>::SharedPtr subscription_;
};

int main(int argc, char *argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<SubscriberNode>());
  rclcpp::shutdown();
  return 0;
}
