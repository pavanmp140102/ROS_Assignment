#include <chrono>
#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "training_interfaces/msg/person.hpp"

using namespace std::chrono_literals;

class PublisherNode : public rclcpp::Node
{
public:
  PublisherNode() : Node("publisher_node")
  {
    publisher_ = this->create_publisher<training_interfaces::msg::Person>("person_topic", 10);
    timer_ = this->create_wall_timer(500ms, std::bind(&PublisherNode::timer_callback, this));
  }

private:
  void timer_callback()
  {
    auto message = training_interfaces::msg::Person();
    message.name = "John Doe";
    message.age = 30;
    RCLCPP_INFO(this->get_logger(), "Publishing: Name: '%s', Age: '%d'", message.name.c_str(), message.age);
    publisher_->publish(message);
  }

  rclcpp::Publisher<training_interfaces::msg::Person>::SharedPtr publisher_;
  rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char *argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<PublisherNode>());
  rclcpp::shutdown();
  return 0;
}

