#include "rclcpp/rclcpp.hpp"
#include "training_interfaces/srv/value.hpp"
#include <memory>

void handle_request(const std::shared_ptr<training_interfaces::srv::Value::Request> request,
                    std::shared_ptr<training_interfaces::srv::Value::Response> response)
{
  response->val = request->a + request->b;
  RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Adding: a=%d, b=%d -> val=%d", request->a, request->b, response->val);
}

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  auto node = rclcpp::Node::make_shared("service_server");
  auto service = node->create_service<training_interfaces::srv::Value>("add_values", &handle_request);

  RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Service ready to add values.");
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
