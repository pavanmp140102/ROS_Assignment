from training_interfaces.srv._value import Value  # noqa: F401
