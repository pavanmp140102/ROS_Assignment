from training_interfaces.msg._person import Person  # noqa: F401
