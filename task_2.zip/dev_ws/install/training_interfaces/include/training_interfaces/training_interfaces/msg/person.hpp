// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TRAINING_INTERFACES__MSG__PERSON_HPP_
#define TRAINING_INTERFACES__MSG__PERSON_HPP_

#include "training_interfaces/msg/detail/person__struct.hpp"
#include "training_interfaces/msg/detail/person__builder.hpp"
#include "training_interfaces/msg/detail/person__traits.hpp"

#endif  // TRAINING_INTERFACES__MSG__PERSON_HPP_
