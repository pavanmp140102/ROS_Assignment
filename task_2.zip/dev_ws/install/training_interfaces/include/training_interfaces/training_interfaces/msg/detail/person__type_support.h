// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from training_interfaces:msg/Person.idl
// generated code does not contain a copyright notice

#ifndef TRAINING_INTERFACES__MSG__DETAIL__PERSON__TYPE_SUPPORT_H_
#define TRAINING_INTERFACES__MSG__DETAIL__PERSON__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "training_interfaces/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_training_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  training_interfaces,
  msg,
  Person
)();

#ifdef __cplusplus
}
#endif

#endif  // TRAINING_INTERFACES__MSG__DETAIL__PERSON__TYPE_SUPPORT_H_
