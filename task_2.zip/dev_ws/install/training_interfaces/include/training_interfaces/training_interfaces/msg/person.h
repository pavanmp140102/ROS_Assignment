// generated from rosidl_generator_c/resource/idl.h.em
// with input from training_interfaces:msg/Person.idl
// generated code does not contain a copyright notice

#ifndef TRAINING_INTERFACES__MSG__PERSON_H_
#define TRAINING_INTERFACES__MSG__PERSON_H_

#include "training_interfaces/msg/detail/person__struct.h"
#include "training_interfaces/msg/detail/person__functions.h"
#include "training_interfaces/msg/detail/person__type_support.h"

#endif  // TRAINING_INTERFACES__MSG__PERSON_H_
