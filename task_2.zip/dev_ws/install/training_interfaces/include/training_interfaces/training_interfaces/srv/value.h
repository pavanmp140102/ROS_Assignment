// generated from rosidl_generator_c/resource/idl.h.em
// with input from training_interfaces:srv/Value.idl
// generated code does not contain a copyright notice

#ifndef TRAINING_INTERFACES__SRV__VALUE_H_
#define TRAINING_INTERFACES__SRV__VALUE_H_

#include "training_interfaces/srv/detail/value__struct.h"
#include "training_interfaces/srv/detail/value__functions.h"
#include "training_interfaces/srv/detail/value__type_support.h"

#endif  // TRAINING_INTERFACES__SRV__VALUE_H_
